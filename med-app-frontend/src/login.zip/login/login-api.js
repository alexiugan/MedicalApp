import {HOST} from '../commons/hosts';
import RestApiClient from "../commons/api/rest-client";


const endpoint = {
    caregiver: '/users'
};


function postLogin(login, callback){
    let request = new Request(HOST.backend_api + endpoint.caregiver + "/login" , {
        method: 'POST',
        headers : {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(login)
    });

    console.log("URL: " + request.url);
    //localStorage.setItem("login", login.role.toString());
    RestApiClient.performRequest(request, callback);

}

export {
    postLogin
};
